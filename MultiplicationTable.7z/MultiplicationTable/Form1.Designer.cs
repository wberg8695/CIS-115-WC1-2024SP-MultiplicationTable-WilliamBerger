﻿namespace MultiplicationTable
{
    partial class MultiplicationTable
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            calculateButton = new Button();
            integer = new Label();
            outputLabel1 = new Label();
            inputBox = new TextBox();
            outputLabel2 = new Label();
            outputLabel3 = new Label();
            outputLabel4 = new Label();
            outputLabel5 = new Label();
            outputLabel6 = new Label();
            outputLabel7 = new Label();
            outputLabel8 = new Label();
            outputLabel9 = new Label();
            outputLabel10 = new Label();
            SuspendLayout();
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(348, 79);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(94, 29);
            calculateButton.TabIndex = 0;
            calculateButton.Text = "Calculate";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += CalculateButton_Click;
            // 
            // integer
            // 
            integer.AutoSize = true;
            integer.Location = new Point(80, 83);
            integer.Name = "integer";
            integer.Size = new Size(114, 20);
            integer.TabIndex = 1;
            integer.Text = "Enter an Integer";
            // 
            // outputLabel1
            // 
            outputLabel1.BorderStyle = BorderStyle.Fixed3D;
            outputLabel1.Location = new Point(53, 124);
            outputLabel1.Name = "outputLabel1";
            outputLabel1.Size = new Size(80, 25);
            outputLabel1.TabIndex = 2;
            // 
            // inputBox
            // 
            inputBox.Location = new Point(225, 81);
            inputBox.Name = "inputBox";
            inputBox.Size = new Size(80, 27);
            inputBox.TabIndex = 3;
            // 
            // outputLabel2
            // 
            outputLabel2.BorderStyle = BorderStyle.Fixed3D;
            outputLabel2.Location = new Point(139, 124);
            outputLabel2.Name = "outputLabel2";
            outputLabel2.Size = new Size(80, 25);
            outputLabel2.TabIndex = 4;
            // 
            // outputLabel3
            // 
            outputLabel3.BorderStyle = BorderStyle.Fixed3D;
            outputLabel3.Location = new Point(225, 124);
            outputLabel3.Name = "outputLabel3";
            outputLabel3.Size = new Size(80, 25);
            outputLabel3.TabIndex = 5;
            // 
            // outputLabel4
            // 
            outputLabel4.BorderStyle = BorderStyle.Fixed3D;
            outputLabel4.Location = new Point(311, 124);
            outputLabel4.Name = "outputLabel4";
            outputLabel4.Size = new Size(80, 25);
            outputLabel4.TabIndex = 6;
            // 
            // outputLabel5
            // 
            outputLabel5.BorderStyle = BorderStyle.Fixed3D;
            outputLabel5.Location = new Point(397, 124);
            outputLabel5.Name = "outputLabel5";
            outputLabel5.Size = new Size(80, 25);
            outputLabel5.TabIndex = 7;
            // 
            // outputLabel6
            // 
            outputLabel6.BorderStyle = BorderStyle.Fixed3D;
            outputLabel6.Location = new Point(53, 158);
            outputLabel6.Name = "outputLabel6";
            outputLabel6.Size = new Size(80, 25);
            outputLabel6.TabIndex = 8;
            // 
            // outputLabel7
            // 
            outputLabel7.BorderStyle = BorderStyle.Fixed3D;
            outputLabel7.Location = new Point(139, 158);
            outputLabel7.Name = "outputLabel7";
            outputLabel7.Size = new Size(80, 25);
            outputLabel7.TabIndex = 9;
            // 
            // outputLabel8
            // 
            outputLabel8.BorderStyle = BorderStyle.Fixed3D;
            outputLabel8.Location = new Point(225, 158);
            outputLabel8.Name = "outputLabel8";
            outputLabel8.Size = new Size(80, 25);
            outputLabel8.TabIndex = 10;
            // 
            // outputLabel9
            // 
            outputLabel9.BorderStyle = BorderStyle.Fixed3D;
            outputLabel9.Location = new Point(311, 158);
            outputLabel9.Name = "outputLabel9";
            outputLabel9.Size = new Size(80, 25);
            outputLabel9.TabIndex = 11;
            // 
            // outputLabel10
            // 
            outputLabel10.BorderStyle = BorderStyle.Fixed3D;
            outputLabel10.Location = new Point(397, 158);
            outputLabel10.Name = "outputLabel10";
            outputLabel10.Size = new Size(80, 25);
            outputLabel10.TabIndex = 12;
            // 
            // MultiplicationTable
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(515, 228);
            Controls.Add(outputLabel10);
            Controls.Add(outputLabel9);
            Controls.Add(outputLabel8);
            Controls.Add(outputLabel7);
            Controls.Add(outputLabel6);
            Controls.Add(outputLabel5);
            Controls.Add(outputLabel4);
            Controls.Add(outputLabel3);
            Controls.Add(outputLabel2);
            Controls.Add(inputBox);
            Controls.Add(outputLabel1);
            Controls.Add(integer);
            Controls.Add(calculateButton);
            Name = "MultiplicationTable";
            Text = "Multiplication Table";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button calculateButton;
        private Label integer;
        private Label outputLabel1;
        private TextBox inputBox;
        private Label outputLabel2;
        private Label outputLabel3;
        private Label outputLabel4;
        private Label outputLabel5;
        private Label outputLabel6;
        private Label outputLabel7;
        private Label outputLabel8;
        private Label outputLabel9;
        private Label outputLabel10;
    }
}
