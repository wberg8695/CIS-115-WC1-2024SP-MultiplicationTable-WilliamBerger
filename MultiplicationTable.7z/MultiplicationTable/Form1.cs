namespace MultiplicationTable
{
    public partial class MultiplicationTable : Form
    {
        public MultiplicationTable()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            int integer, altIn, product;
            string input, output, error;
            input = inputBox.Text;
            altIn = Convert.ToInt32(input);
            error = "Error";
            if (altIn >= 0 && altIn <= 99999)
            for (integer = 1; integer < 11; ++integer)
            {
               product = altIn * integer;
               output = Convert.ToString(product);
               switch (integer)
               {
                   case 1:
                       outputLabel1.Text = output;
                       break;
                   case 2:
                       outputLabel2.Text = output;
                       break;
                   case 3:
                       outputLabel3.Text = output;
                       break;
                   case 4:
                       outputLabel4.Text = output;
                       break;
                   case 5:
                       outputLabel5.Text = output;
                       break;
                   case 6:
                       outputLabel6.Text = output;
                       break;
                   case 7:
                       outputLabel7.Text = output;
                       break;
                   case 8:
                       outputLabel8.Text = output;
                       break;
                   case 9:
                       outputLabel9.Text = output;
                       break;
                   case 10:
                       outputLabel10.Text = output;
                       break;
                   default:
                       outputLabel1.Text = error;
                       outputLabel2.Text = error;
                       outputLabel3.Text = error;
                       outputLabel4.Text = error;
                       outputLabel5.Text = error;
                       outputLabel6.Text = error;
                       outputLabel7.Text = error;
                       outputLabel8.Text = error;
                       outputLabel9.Text = error;
                       outputLabel10.Text = error;
                       break;
               }
            }
            else
            {
                outputLabel1.Text = error;
                outputLabel2.Text = error;
                outputLabel3.Text = error;
                outputLabel4.Text = error;
                outputLabel5.Text = error;
                outputLabel6.Text = error;
                outputLabel7.Text = error;
                outputLabel8.Text = error;
                outputLabel9.Text = error;
                outputLabel10.Text = error;
            }
        }
    }
}
